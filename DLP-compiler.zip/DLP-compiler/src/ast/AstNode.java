package ast;

public interface AstNode {

    int getLine();
    int getColumn();
}
