package ast.expression.value;

import ast.expression.AbstractExpression;

import java.beans.Expression;

public class CharLiteral extends AbstractExpression {


    public CharLiteral(int line, int column) {
        super(line, column);
    }
}
