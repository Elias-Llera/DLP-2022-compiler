package ast.expression.value;

import ast.expression.AbstractExpression;

public class DoubleLiteral extends AbstractExpression {
    public DoubleLiteral(int line, int column) {
        super(line, column);
    }
}
