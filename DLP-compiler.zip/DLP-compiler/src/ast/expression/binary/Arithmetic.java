package ast.expression.binary;

import ast.expression.AbstractExpression;

public class Arithmetic extends AbstractExpression {

    public Arithmetic(int line, int column) {
        super(line, column);
    }

}
