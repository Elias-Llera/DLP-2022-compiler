package ast.expression.binary;

public class Comparisson extends BinaryOperation{
    public Comparisson(int line, int column) {
        super(line, column);
    }
}
