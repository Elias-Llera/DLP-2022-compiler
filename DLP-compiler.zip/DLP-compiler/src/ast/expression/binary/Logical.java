package ast.expression.binary;

public class Logical extends BinaryOperation{
    public Logical(int line, int column) {
        super(line, column);
    }
}
