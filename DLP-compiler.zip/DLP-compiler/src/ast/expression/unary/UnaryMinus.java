package ast.expression.unary;

import ast.expression.binary.BinaryOperation;

public class UnaryMinus extends UnaryOperation {

    public UnaryMinus(int line, int column) {
        super(line, column);
    }

}
