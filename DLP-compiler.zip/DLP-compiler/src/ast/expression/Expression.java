package ast.expression;

public interface Expression {
}
