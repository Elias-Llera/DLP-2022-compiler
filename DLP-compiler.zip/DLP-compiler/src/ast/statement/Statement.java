package ast.statement;

public interface Statement {
}
