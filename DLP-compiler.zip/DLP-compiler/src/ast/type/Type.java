package ast.type;

public interface Type {
}
