package ast.definition;

public class VariableDefinition extends AbstractDefinition{

    public VariableDefinition(int line, int column) {
        super(line, column);
    }
}
